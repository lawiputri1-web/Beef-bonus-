# Beef Bonus — Fabric 1.21.11

Eating **raw beef or cooked beef** gives the player one small random bonus reward. This is a Fabric mod and does not use a datapack.

## Possible rewards
- 3 Iron Ingots
- 2 Gold Ingots
- 1 Diamond
- 3 Bottles o' Enchanting
- 1 Golden Apple
- 8 Arrows
- 1 Ender Pearl
- 3 Emeralds

Rewards are intentionally modest and random. If the inventory is full, the reward drops on the ground.

## Build
This environment could not download Gradle/Fabric dependencies, so this package contains the source project rather than a compiled, verified `.jar`.

1. Install Java 21 and Gradle, or open the folder in IntelliJ IDEA with Fabric Loom support.
2. Run `gradle build` in this project directory.
3. Find the output in `build/libs/` and use the non-`-sources.jar` file.
4. Install Fabric Loader and Fabric API for Minecraft Java 1.21.11, then place the JAR in `.minecraft/mods`.

## Test status
Not compiled or tested in-game here. The source uses a Mixin hook on the food-consumption completion method, so the reward is intended to trigger when eating completes. This still has not been compiled or tested in-game in this environment. Please send any build error text for corrections.
