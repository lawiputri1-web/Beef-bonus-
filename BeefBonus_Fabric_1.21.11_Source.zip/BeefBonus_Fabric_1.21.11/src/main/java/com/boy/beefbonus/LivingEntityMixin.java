package com.boy.beefbonus;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    private static final Random BEEFBONUS_RANDOM = new Random();

    @Inject(method = "completeUsingItem", at = @At("HEAD"))
    private void beefbonus$onFoodConsumed(CallbackInfo ci) {
        LivingEntity entity = (LivingEntity) (Object) this;
        if (!(entity instanceof ServerPlayer player)) return;

        ItemStack eaten = player.getUseItem();
        Item item = eaten.getItem();
        if (item != Items.BEEF && item != Items.COOKED_BEEF) return;

        ItemStack reward = switch (BEEFBONUS_RANDOM.nextInt(8)) {
            case 0 -> new ItemStack(Items.IRON_INGOT, 3);
            case 1 -> new ItemStack(Items.GOLD_INGOT, 2);
            case 2 -> new ItemStack(Items.DIAMOND, 1);
            case 3 -> new ItemStack(Items.EXPERIENCE_BOTTLE, 3);
            case 4 -> new ItemStack(Items.GOLDEN_APPLE, 1);
            case 5 -> new ItemStack(Items.ARROW, 8);
            case 6 -> new ItemStack(Items.ENDER_PEARL, 1);
            default -> new ItemStack(Items.EMERALD, 3);
        };

        if (!player.getInventory().add(reward)) {
            player.drop(reward, false);
        }
        player.sendSystemMessage(Component.literal(
            "§6[Beef Bonus] §fBonus: §e" + reward.getHoverName().getString()));
    }
}
